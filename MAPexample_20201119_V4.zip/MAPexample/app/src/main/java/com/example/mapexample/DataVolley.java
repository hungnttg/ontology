package com.example.mapexample;

import android.content.Context;
import android.os.Build;
import android.widget.TextView;

import androidx.annotation.RequiresApi;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;

import com.android.volley.RequestQueue;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;


public class DataVolley {
//https://batdongsanabc.000webhostapp.com/mob403lab5/get_product_detail.php?pid=52
   static String jsonStr=null;
    public void getJSONArray(Context context, TextView textView)
    {
        RequestQueue queue = Volley.newRequestQueue(context);
        String url = "https://batdongsanabc.000webhostapp.com/mob403lab5/get_product_detail.php?pid=52";
        //String url = "https://batdongsanabc.000webhostapp.com/mob403lab3/person_array.json";
        JsonArrayRequest req = new JsonArrayRequest(url, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                for(int i=0;i<response.length();i++)
                {
                    try {
                        JSONObject person = response.getJSONObject(i);
                        String name = person.getString("name");
                        String email = person.getString("email");
                        JSONObject phone = person.getJSONObject("phone");
                        String home = phone.getString("home");
                        String mobile = phone.getString("mobile");
                        jsonStr += "Name: "+name+"\n\n";
                        jsonStr += "Email: "+email+"\n\n";
                        jsonStr += "phone: "+phone+"\n\n";
                        jsonStr += "Mobile: "+mobile+"\n\n";
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                textView.setText(jsonStr);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                error.getMessage();
            }
        });
        queue.add(req);
    }
/////
public void getJSONObject_POST(Context context, TextView textView)
{
    RequestQueue queue = Volley.newRequestQueue(context);
    String url = "https://batdongsanabc.000webhostapp.com/mob403lab5/get_product_detail.php";
    //String url = "https://batdongsanabc.000webhostapp.com/mob403lab3/person_array.json";
    HashMap<String, String> params = new HashMap<String, String>();
    params.put("pid", "52");

    JsonObjectRequest req = new JsonObjectRequest(Request.Method.POST, url, new JSONObject(params),
            new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {
                    try {
                        VolleyLog.v("Response:%n %s", response.toString(4));
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }, new Response.ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError error) {
            VolleyLog.e("Error: ", error.getMessage());
        }
    });
    queue.add(req);
}

    public void getJSONObject_GET(Context context, TextView textView)
    {
        RequestQueue queue = Volley.newRequestQueue(context);
        //String url = String.format("https://batdongsanabc.000webhostapp.com/mob403lab5/get_product_detail.php?param1=%1$s&param2=%2$s",num1,
        //                           num2);
        String url = String.format("https://batdongsanabc.000webhostapp.com/mob403lab5/get_product_detail.php?pid=%1$s",52);
        //String url = "https://batdongsanabc.000webhostapp.com/mob403lab3/person_array.json";
        HashMap<String, String> params = new HashMap<String, String>();
        params.put("pid", "52");

        JsonObjectRequest req = new JsonObjectRequest(Request.Method.GET, url, new JSONObject(params),
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            //////////////////// start to change this fragment/////////////////
                            JSONArray arr =  response.getJSONArray("products");
                            for(int i=0;i<arr.length();i++)
                            {
                                try {
                                    String pid = arr.getJSONObject(i).getString("pid");
                                    String name = arr.getJSONObject(i).getString("name");
                                    String price = arr.getJSONObject(i).getString("price");
                                    String des = arr.getJSONObject(i).getString("description");
                                    jsonStr += "Pid: "+pid+"\n\n";
                                    jsonStr += "name: "+name+"\n\n";
                                    jsonStr += "price: "+price+"\n\n";
                                    jsonStr += "des: "+des+"\n\n";
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }
                            textView.setText(jsonStr);
                            //////////////////// the end of changing this fragment////////////////
                            VolleyLog.v("Response:%n %s", response.toString(4));
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.e("Error: ", error.getMessage());
            }
        });
        queue.add(req);
    }

    //xu ly ham nay nhe
    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    public String getJSONObject_GET(Context context) throws UnsupportedEncodingException {
        RequestQueue queue = Volley.newRequestQueue(context);
//        //String url = String.format("https://batdongsanabc.000webhostapp.com/mob403lab5/get_product_detail.php?param1=%1$s&param2=%2$s",num1,
//        //                           num2);
//        String url = String.format("https://batdongsanabc.000webhostapp.com/mob403lab5/get_product_detail.php?pid=%1$s",52);


        String paramGetOfGoogleMap = "Dải băng Greenland";//tham so lay tu google map
        String p = paramGetOfGoogleMap.replaceAll("\\s+","%20");//replace dau cach boi %20
        String url = String.format("http://192.168.1.120/ontology/index_data_para_ont.php?name=%1$s",p);
        //String url = "http://192.168.1.120/ontology/index_data_para_ont.php?name=Dải băng Greenland";
        //String url1 = java.net.URLDecoder.decode(urlOld, StandardCharsets.UTF_8.name());
        HashMap<String, String> params = new HashMap<String, String>();
        //params.put("name", "Dải băng Greenland");

        JsonObjectRequest req = new JsonObjectRequest(Request.Method.GET, url, new JSONObject(params),
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            //////////////////// start to change this fragment/////////////////
                            JSONArray arr =  response.getJSONArray("products");
                            for(int i=0;i<arr.length();i++)
                            {
                                try {
                                    String summary = arr.getJSONObject(i).getString("summary");
                                    String infobox = arr.getJSONObject(i).getString("infobox");

                                    jsonStr += "summary: "+summary+"\n\n";
                                    jsonStr += "infobox: "+infobox+"\n\n";

                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }
                            //return jsonStr;
                            //////////////////// the end of changing this fragment////////////////
                            VolleyLog.v("Response:%n %s", response.toString(4));
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.e("Error: ", error.getMessage());
            }
        });
        queue.add(req);
        return jsonStr;
    }


}
