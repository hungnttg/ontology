package com.example.mapexample;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.os.Message;
import android.text.Html;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.webkit.ClientCertRequest;
import android.webkit.GeolocationPermissions;
import android.webkit.HttpAuthHandler;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.SafeBrowsingResponse;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.mapexample.siri.MainActivity;
import com.google.android.material.snackbar.Snackbar;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DetailLinkActivity extends AppCompatActivity {
    WebView webView;
    Context context = this;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_link);
        webView = findViewById(R.id.lab5webview);

        webView.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
        webView.getSettings().setBuiltInZoomControls(true);
        webView.setWebChromeClient(new GeoWebChromeClient());

        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setGeolocationEnabled(true);
        webView.setWebChromeClient(new GeoWebChromeClient());
        webView.setWebViewClient(new MyWebViewClient1());

        webView.loadUrl("http://www.google.com/maps");


    }
    @Override
    public void onBackPressed() {
        // Pop the browser back stack or exit the activity
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
    private class MyWebViewClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView webView, String url) {
            return false;
        }
    }


    private static final int RP_ACCESS_LOCATION = 1001;


    private String mGeolocationOrigin;
    private GeolocationPermissions.Callback mGeolocationCallback;

    public class GeoWebChromeClient extends WebChromeClient {
        @Override
        public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
            final String permission = Manifest.permission.ACCESS_FINE_LOCATION;
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M ||
                    ContextCompat.checkSelfPermission(DetailLinkActivity.this, permission) == PackageManager.PERMISSION_GRANTED) {
                // that is you already implement, but it works only
                // we're on SDK < 23 OR user has ALREADY granted permission
                callback.invoke(origin, true, false);
            } else {
                if (ActivityCompat.shouldShowRequestPermissionRationale(DetailLinkActivity.this, permission)) {
                    // user has denied this permission before and selected [/] DON'T ASK ME AGAIN
                    // TODO Best Practice: show an AlertDialog explaining why the user could allow this permission, then ask again
                } else {
                    // store
                    mGeolocationOrigin = origin;
                    mGeolocationCallback = callback;
                    // ask the user for permissions
                    ActivityCompat.requestPermissions(DetailLinkActivity.this, new String[] {permission}, RP_ACCESS_LOCATION);
                }
            }
        }

    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case RP_ACCESS_LOCATION:
                boolean allow = false;
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // user has allowed these permissions
                    allow = true;
                }
                if (mGeolocationCallback != null) {
                    // use stored callback and origin for allowing Geolocation permission for WebView
                    mGeolocationCallback.invoke(mGeolocationOrigin, allow, false);
                }
                break;
        }
    }
    public static String serverResponse = null;//response of server
    public class MyWebViewClient1 extends WebViewClient {
        @RequiresApi(api = Build.VERSION_CODES.KITKAT)
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            // When user clicks a hyperlink, load in the existing WebView
            view.loadUrl(url);
            //loadData(url);
            return true;
        }

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            super.onPageStarted(view, url, favicon);
        }
        String result="KQ";//request of client

        @RequiresApi(api = Build.VERSION_CODES.KITKAT)
        @Override
        public void onPageFinished(WebView view, String url) {

            if(url.equals(webView.getOriginalUrl())) {
                // Fetch the Runnable for the OriginalUrl.
                webView.getOriginalUrl();
                // Is it valid?
            }
            super.onPageFinished(view, url);
        }

        public String getSubPath(String para)
        {
            String newPara="";
            try{
                newPara = para.substring(34,para.indexOf("/",36));
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
            return  newPara;
        }


        @Override
        public void onPageCommitVisible(WebView view, String url) {
            super.onPageCommitVisible(view, url);
        }

        String subPathVariable="";
        String pageid ="";
        @RequiresApi(api = Build.VERSION_CODES.KITKAT)
        @Override
        public void doUpdateVisitedHistory(WebView view, String url, boolean isReload) {

            String result1="KQ";
            try {
                result1 = java.net.URLDecoder.decode(url, StandardCharsets.UTF_8.name());
            } catch (UnsupportedEncodingException e) {
                // not going to happen - value came from JDK's own StandardCharsets
            }
                //Toast.makeText(getApplicationContext(),result1,Toast.LENGTH_LONG).show();

             subPathVariable = getSubPath(result1);


            Snackbar.make(findViewById(R.id.lab5webview),subPathVariable,50000)
                    .setAction("More Info", new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            try {
                                //Call API of CongNV
                                getJSONObject_GET_Slave(getApplicationContext(),subPathVariable);
                            } catch (UnsupportedEncodingException | JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    }).show();



            super.doUpdateVisitedHistory(view, url, isReload);
        }
        //////API of CongNV//////////////
        @RequiresApi(api = Build.VERSION_CODES.KITKAT)
        public void showDialogPageID(String pid)
        {
           androidx.appcompat.app.AlertDialog.Builder builder =
                   new androidx.appcompat.app.AlertDialog.Builder(context);
            builder.setTitle("Summary");
            builder.setMessage(pid);
            builder.setPositiveButton("More Info", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    //Toast.makeText(context,"ban chon OK",Toast.LENGTH_SHORT).show();
                    try {

                        getJSONObject_GET_Data(getApplicationContext(),pid);
                        Intent intent = new Intent(DetailLinkActivity.this,MainActivity.class);
                        context.startActivity(intent);
                        //showDialogPageInfo();
                    } catch (UnsupportedEncodingException | JSONException e) {
                        e.printStackTrace();
                    }

                }
            });
            builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Toast.makeText(context,"ban chon Cancel",Toast.LENGTH_SHORT).show();
                }
            });
            AlertDialog dialog = builder.create();
            dialog.show();
        }

        //////API of CongNV//////////////
        @RequiresApi(api = Build.VERSION_CODES.KITKAT)
        public void showDialogPageID_with_CardView(String pid)
        {
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            LayoutInflater inflater = getLayoutInflater();
            View view = inflater.inflate(R.layout.card_view_summary,null);
            builder.setView(view);
            final ImageView imgObj = (ImageView)view.findViewById(R.id.imgObj);
            final TextView txtObj = (TextView) view.findViewById(R.id.txtObj);
            txtObj.setText(pid);
            builder.setTitle("Thông tin về...");
            //builder.setMessage(pid);
            builder.setPositiveButton("More Info", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    //Toast.makeText(context,"ban chon OK",Toast.LENGTH_SHORT).show();
                    try {

                        getJSONObject_GET_Data(getApplicationContext(),pid);
                        Intent intent = new Intent(DetailLinkActivity.this,MainActivity.class);
                        context.startActivity(intent);
                        //showDialogPageInfo();
                    } catch (UnsupportedEncodingException | JSONException e) {
                        e.printStackTrace();
                    }

                }
            });
            builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Toast.makeText(context,"ban chon Cancel",Toast.LENGTH_SHORT).show();
                }
            });
            AlertDialog dialog = builder.create();
            dialog.show();
            ////

        }

        public void showDialogPageInfo(String info)
        {
            androidx.appcompat.app.AlertDialog.Builder builder =
                    new androidx.appcompat.app.AlertDialog.Builder(context);
            builder.setTitle("More Info");
            builder.setMessage(info);
            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    //Toast.makeText(context,"ban chon OK",Toast.LENGTH_SHORT).show();

                }
            });
            builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                }
            });
            AlertDialog dialog = builder.create();
            dialog.show();

        }

        String jsonStr="";
        String htmlStr="";
        @RequiresApi(api = Build.VERSION_CODES.KITKAT)
        public String getJSONObject_GET_Data(Context context, String para) throws UnsupportedEncodingException, JSONException {
            jsonStr="";
            htmlStr="";
            RequestQueue queue = Volley.newRequestQueue(context);
            String url1 = String.format("https://vi.wikipedia.org/w/api.php?action=parse&format=json&prop=wikitext&mobileformat=1&prop=wikitext&pageid=%1$s",para);
            HashMap<String, String> params = new HashMap<String, String>();
            params.put("pageid", para);

            JsonObjectRequest req = new JsonObjectRequest(Request.Method.GET, url1, new JSONObject(params), new Response.Listener<JSONObject>() {
                @RequiresApi(api = Build.VERSION_CODES.KITKAT)
                @Override
                public void onResponse(JSONObject response) {
                    try {
                        JSONObject arr = response.getJSONObject("parse");
                        String title = arr.getString("title");
                        String pageid = arr.getString("pageid");
                        String wikitext = arr.getString("wikitext");
                        jsonStr += "title: "+title+"\n\n";
                        jsonStr += "pageid: "+pageid+"\n\n";
                        jsonStr += "wikitext: "+wikitext+"\n\n";

                        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
                            htmlStr = String.valueOf(Html.fromHtml(jsonStr,Html.FROM_HTML_MODE_LEGACY));
                        }
                        else
                        {
                            htmlStr = String.valueOf(Html.fromHtml(jsonStr));
                        }
                        DetailLinkActivity.serverResponse=htmlStr;
                        //Toast.makeText(context,htmlStr,Toast.LENGTH_LONG).show();
                        showDialogPageInfo(htmlStr);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    error.getMessage();
                }
            });

            queue.add(req);
            return htmlStr;
        }
        String firstpageid = "";
        @RequiresApi(api = Build.VERSION_CODES.KITKAT)
        public String getJSONObject_GET_Slave(Context context, String para) throws UnsupportedEncodingException, JSONException {
            RequestQueue queue = Volley.newRequestQueue(context);

            String paramGetOfGoogleMap = para;//tham so lay tu google map
            List<String> elephantList = Arrays.asList(paramGetOfGoogleMap.split(","));
            paramGetOfGoogleMap= elephantList.get(0);
            //paramGetOfGoogleMap = "Hai bà trưng";
            paramGetOfGoogleMap = URLEncoder.encode(paramGetOfGoogleMap, "utf-8");
            //paramGetOfGoogleMap = "Hai_B%C3%A0_Tr%C6%B0ng";
                //String url ="https://vi.wikipedia.org/w/api.php?action=query&format=json&list=search&utf8=1&srsearch="+paramGetOfGoogleMap;
            String url ="http://ontweb-embedded.herokuapp.com/query?q="+paramGetOfGoogleMap;
            JsonObjectRequest req = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
                @RequiresApi(api = Build.VERSION_CODES.KITKAT)
                @Override
                public void onResponse(JSONObject response) {
                    try {
                        JSONArray jsonArray = response.getJSONArray("data");
                        for(int i=0;i<jsonArray.length();i++)
                        {
                            JSONObject jsonObject = jsonArray.getJSONObject(i);
                            firstpageid =jsonObject.getString("summary");
                            break;
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    //showDialogPageID(firstpageid);//Show Dialog of CongNV's API
                    showDialogPageID_with_CardView(firstpageid);
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    error.getMessage();
                }
            });
            queue.add(req);
            return firstpageid;
        }
        @Override
        public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
            Toast.makeText(getApplicationContext(),"onRenderProcessGone",Toast.LENGTH_LONG).show();
            return super.onRenderProcessGone(view, detail);
        }

        @Override
        public void onFormResubmission(WebView view, Message dontResend, Message resend) {
            Toast.makeText(getApplicationContext(),"onFormResubmission",Toast.LENGTH_LONG).show();
            super.onFormResubmission(view, dontResend, resend);
        }

        @Override
        public void onLoadResource(WebView view, String url) {
            super.onLoadResource(view, url);
        }

    }


}