package com.example.mapexample.siri;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.example.mapexample.R;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    OntAdapter adapter;
    List<OntModel> list = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = findViewById(R.id.recycler1);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);

        DividerItemDecoration mDividerItemDecoration = new DividerItemDecoration(recyclerView.getContext(),
                linearLayoutManager.getOrientation());
        recyclerView.addItemDecoration(mDividerItemDecoration);

        recyclerView.setLayoutManager(linearLayoutManager);
        list.add(new OntModel("","aaaaa","bbbb",true));
        list.add(new OntModel("","aaaaa","bbbb",false));
        list.add(new OntModel("","aaaaa",new Object(),true));
        list.add(new OntModel("","aaaaa","bbbb",false));
        list.add(new OntModel("","aaaaa",new Object(),false));
        list.add(new OntModel("","aaaaa","bbbb",true));

        adapter = new OntAdapter(this,list);
        recyclerView.setAdapter(adapter);
    }
}