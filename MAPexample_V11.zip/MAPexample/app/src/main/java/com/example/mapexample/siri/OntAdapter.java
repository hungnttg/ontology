package com.example.mapexample.siri;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mapexample.R;

import java.io.IOException;
import java.net.URL;
import java.util.List;

public class OntAdapter extends RecyclerView.Adapter<OntAdapter.ViewHolder> {
    private Context context;
    private List<OntModel> list;

    public OntAdapter(Context context, List<OntModel> list) {
        this.context = context;
        this.list = list;
    }

    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_view,null);
        return new ViewHolder((view));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Bitmap bmp = null;
        try {
            bmp = BitmapFactory.decodeFile(String.valueOf(new URL(list.get(position).getUrlImage()).openStream()));
        } catch (IOException e) {
            e.printStackTrace();
        }
        holder.img.setImageBitmap(bmp);
        holder.title.setText(list.get(position).getTitle());
        if(list.get(position).getEntity() instanceof String)
        {
            holder.obj.setText(String.valueOf(list.get(position).getEntity()));
            holder.arrow.setVisibility(View.INVISIBLE);
        }
       else if(list.get(position).getEntity() instanceof Object)
        {
            holder.obj.setText(String.valueOf(list.get(position).getEntity()));
            holder.arrow.setVisibility(View.VISIBLE);
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //Toast.makeText(context,"Day la 1 object",Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(context,MainActivity2.class);
                    context.startActivity(intent);
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder{
        ImageView img,arrow;
        TextView title, obj;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            img = itemView.findViewById(R.id.img1);
            arrow = itemView.findViewById(R.id.imgArrow1);
            title = itemView.findViewById(R.id.tv1);
            obj = itemView.findViewById(R.id.tv2);
        }
    }
}
