package com.example.mapexample.siri;

public class OntModel {
    private String urlImage;
    private String title;
    private Object entity;
    private boolean isObject;

    public OntModel(String image, String title, Object entity, boolean isObject) {
        this.urlImage = image;
        this.title = title;
        this.entity = entity;
        this.isObject = isObject;
    }

    public OntModel() {
    }

    public String getUrlImage() {
        return urlImage;
    }

    public void setUrlImage(String urlImage) {
        this.urlImage = urlImage;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Object getEntity() {
        return entity;
    }

    public void setEntity(Object entity) {
        this.entity = entity;
    }

    public boolean isObject() {
        return isObject;
    }

    public void setObject(boolean object) {
        isObject = object;
    }
}
